package ejercicio1;

public class Ejercicio1 {

    public static void main(String[] args) {
        // Antoni   8 6 7 
        // Laura    8 5 5 
        // Aitor    5 3 4 
        // Maria    8 6 6 
        // Pablo    8 6 5 
        
        // Crea en esta línea la constante "media"
       
        /*
        final var comunes8 = media.apply(8);
        final var comunes8y6 = comunes8.apply(6);
        
        final var antoni = comunes8y6.apply(7);                      // 7
        final var laura = comunes8.apply(5).apply(5);                // 6 
        final var aitor = media.apply(5).apply(3).apply(4);          // 4
        final var maria = comunes8y6.apply(6);                       // 7
        final var pablo = comunes8y6.apply(5);                       // 6     
        */
    }
    
}
