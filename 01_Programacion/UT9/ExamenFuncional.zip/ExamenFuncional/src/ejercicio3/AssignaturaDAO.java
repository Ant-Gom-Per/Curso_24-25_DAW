package ejercicio3;

import java.util.ArrayList;
import java.util.List;

public class AssignaturaDAO {

    public static List<Asignatura> getAll() {
        List<Asignatura> asignaturas = new ArrayList<>();
        asignaturas.add(new Asignatura("Càlcul", 1, 5));
        asignaturas.add(new Asignatura("Física", 1, 4));
        asignaturas.add(new Asignatura("Programació bàsica", 1, 6));
        asignaturas.add(new Asignatura("Sistemes operatius", 2, 5));
        asignaturas.add(new Asignatura("Algorísmia i complexitat", 2, 6));
        asignaturas.add(new Asignatura("Arquitectura de computadors", 2, 5));
        asignaturas.add(new Asignatura("Bases de dades", 3, 5));
        asignaturas.add(new Asignatura("Xarxes de computadors", 3, 5));
        asignaturas.add(new Asignatura("Programació orientada a objectes", 3, 6));
        asignaturas.add(new Asignatura("Introducció a la intel·ligència artificial", 4, 5));
        return asignaturas;
    }
}
