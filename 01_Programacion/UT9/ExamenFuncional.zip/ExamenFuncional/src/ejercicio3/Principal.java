package ejercicio3;

import java.util.List;
import java.util.stream.Collectors;

public class Principal {

    public static void main(String[] args) {
        // A) Muestra aquellos profesores que imparten más de dos asignaturas (muestra el objeto profesor completo) [0.5p]
 
 
        // B) Muestra el nombre de las asignaturas impartidas profesores, sin duplicados y ordenadas alfabéticamente. [0.5p]


        // C) Recoleta y muestra un mapa (Map) donde se asocie para cada nombre de profesor la cantidad de asignaturas que imparte [1p]


        // D) Recoleta y muestra un mapa (Map) donde se asocie para cada nombre de profesor la cantidad de horas de clase que imparte [1p]


        // E) Recoleta y muestra un mapa (Map) donde se asocie para cada DNI de profesor el curso más alto donde imparte clase (si no té ninguna asignatura asociada, el máximo curso será 0) [1.5p]


        // F) Recoleta y muestra un mapa (Map) donde se asocie para cada curso los nombres de asignaturas de ese curso (separadas por un guion " - "). [1.5p]
        
    }

}
