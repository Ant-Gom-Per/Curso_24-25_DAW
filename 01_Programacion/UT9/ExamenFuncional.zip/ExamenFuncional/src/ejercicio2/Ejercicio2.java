package ejercicio2;

import java.util.List;

public class Ejercicio2 {

    public static void main(String[] args) {

        // Crea en esta línea la constante "filtrador"
        /*
        final var filtradorA = filtrador.apply(s -> s.toLowerCase().contains("a"));
        final var filtradorMayor4 = filtrador.apply(s -> s.length() > 4);

        System.out.println(filtradorA.apply(List.of("Alacant", "Elx", "Novelda", "Sax")));                                  // [Alacant, Novelda, Sax]
        System.out.println(filtradorA.apply(List.of("Espanya", "Perú", "Finlàndia", "Regne Unit")));                        // [Espanya, Finlàndia]
        System.out.println(filtradorMayor4.apply(List.of("Alacant", "Elx", "Novelda", "Sax")));                             // [Alacant, Novelda]
        System.out.println(filtradorMayor4.apply(List.of("Espanya", "Perú", "Finlàndia", "Regne Unit")));                   // [Espanya, Finlàndia, Regne Unit]
        System.out.println(filtrador.apply(s -> s.compareTo("G") < 0).apply(List.of("Alacant", "Elx", "Novelda", "Sax")));  // [Alacant, Elx]
        */
    }
    
}
