/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productebd.modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.apache.tomcat.jdbc.pool.DataSource;

/**
 *
 * @author josem
 */
public class ProductoDAOImpl implements ProductoDAO {

    private final DataSource dataSource;

    public ProductoDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public List<Producto> findAll() {
        final String sql = "SELECT * FROM producte";
        List<Producto> productos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            // Aquí la gestión del ResultSet
        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener productos", e);
        }
        return productos;
    }

    @Override
    public Optional<Producto> findById(Long id) {
        final String sql = "SELECT * FROM producte WHERE id = ?";
        
        // Completar código
        
        return Optional.empty();
    }

    @Override
    public boolean insert(Producto producto) {
        final String sql = "INSERT INTO producte (nombre, precio, descripcion) VALUES (?, ?, ?)";
        
        // Completar código
        
        return false;
    }

    @Override
    public boolean update(Producto producto) {
        final String sql = "UPDATE producte SET nombre = ?, precio = ?, descripcion = ? WHERE id = ?";

        // Completar código
        
        return false;
    }

    @Override
    public boolean delete(Producto producto) {
        return deleteById(producto.id());
    }

    @Override
    public boolean deleteById(Long id) {
        final String sql = "DELETE FROM producte WHERE id = ?";

        // Completar código
        
        return false;
    }
}
