/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemploconexion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;

/**
 *
 * @author jrmd
 */
public class Main {

    public static void main(String[] args) {
        final String sentenciaSQL = "SELECT * FROM prova ORDER BY id";
        final String URL = "jdbc:oracle:thin:@localhost:1521:ORCLCDB";          // Ara ja no indiquem usuari ni password a l'URL
        final DataSource datasource;
        final PoolProperties pool;

        try {
            //Class.forName("oracle.jdbc.driver.OracleDriver");
            pool = new PoolProperties();
            pool.setUrl(URL);
            pool.setDriverClassName("oracle.jdbc.driver.OracleDriver");
            pool.setUsername("javauser");
            pool.setPassword("javauser");
            pool.setMaxActive(15);
            pool.setMaxIdle(10);
            pool.setMaxWait(5000);
            
            datasource = new DataSource();
            datasource.setPoolProperties(pool);

            Connection conn = datasource.getConnection();                   // Obtenim la connexió amb "getConnection"
            Statement statement = conn.createStatement();                   // Statement ens permet executar sentències SQL
            ResultSet resultSet = statement.executeQuery(sentenciaSQL);     // executeQuery executa la sentència i retorna un "resultSet"
            while (resultSet.next()) {                                      // Mentre queden registres dins del "resultSet" els recorrem
                int codi = resultSet.getInt("id"); //                   // getInt obté un valor enter de la columna "codigo" del registre actual recorregut
                String nom = resultSet.getString("nom");                 // getString obté un valor String de la columna "nombre" del registre actual recorregut
                System.out.println("Codi: " + codi + " - Nom: " + nom);
            }
            conn.close();                                                   // finalment hem de tancar la connexió 
       // } catch (ClassNotFoundException ex) {
         //   System.out.println("No s'ha trobat eixe driver");
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
}
