package model;

public class EmpleatDAO {
    
}
