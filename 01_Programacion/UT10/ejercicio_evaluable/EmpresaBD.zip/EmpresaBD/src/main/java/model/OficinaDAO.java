package model;

public class OficinaDAO {
    
}
