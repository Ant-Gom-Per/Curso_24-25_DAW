package model;

public class Oficina {
    
}
