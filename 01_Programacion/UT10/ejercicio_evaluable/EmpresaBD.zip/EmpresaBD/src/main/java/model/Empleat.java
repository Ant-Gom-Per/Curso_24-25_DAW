package model;

public class Empleat {
    
}
