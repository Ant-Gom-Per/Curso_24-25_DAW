package p53.util;

public class Interval {
    /*
    Substitueix ací pel codi de la classe Interval que has realitzat anteriorment.
     */

}
