package p53.joc;

public class Coordenada {
    
}
