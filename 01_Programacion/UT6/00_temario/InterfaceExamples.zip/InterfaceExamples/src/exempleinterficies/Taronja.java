/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exempleinterficies;

/**
 *
 * @author jmas
 */
public class Taronja extends Fruita {

    @Override
    public String comEsMenja() {
        return "Partir por la mitad y hacer zumo";
    }
    
}
