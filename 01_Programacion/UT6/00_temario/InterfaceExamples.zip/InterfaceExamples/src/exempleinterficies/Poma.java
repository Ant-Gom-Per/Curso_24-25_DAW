/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exempleinterficies;

/**
 *
 * @author jmas
 */
public class Poma extends Fruita {

    @Override
    public String comEsMenja() {
        return "Pelar y partir";
    }
    
}
