/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exempleinterficies3;

public interface Operable {
    
    public abstract double sumar(Operable altre);
    public abstract double restar(Operable altre);
    public abstract double getValor();
    
}
